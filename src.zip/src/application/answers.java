package application;


import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



public class answers {

	
	
	  private final DatabaseHelper databaseHelper;

	    public answers(DatabaseHelper databaseHelper) {
	        this.databaseHelper = databaseHelper;
	    }
	
	   
	    public void addAnswer(answer answer) throws SQLException {
	    	
	
	    	
	    }
	    
	
	
}
