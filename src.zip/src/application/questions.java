package application;


import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class questions {
	
	  
	  private final DatabaseHelper databaseHelper;

	    public questions(DatabaseHelper databaseHelper) {
	        this.databaseHelper = databaseHelper;
	    }
	
	   
	    
	    
	    public void editQuestions(question question) throws SQLException {
	    	
	    	
	    	
	    }
	
	
}
